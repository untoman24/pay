   __  _  _  ____  ____    ____   ___   __   _  _  ____   __    ___  ____ 
 _(  )/ )( \/ ___)(_  _)  / ___) / __) / _\ ( \/ )(  _ \ / _\  / __)(  __)
/ \) \) \/ (\___ \  )(    \___ \( (__ /    \/ \/ \ ) __//    \( (_ \ ) _) 
\____/\____/(____/ (__)   (____/ \___)\_/\_/\_)(_/(__)  \_/\_/ \___/(____)
                
Fiture :
- New Login
- New Display
- Multi Language
- True Credit Card
- VBV (on/off)
- Bank Account
- Selfie (on/off)
- Panel (Fix soon)
- Panel with password acess
- History Visitor's
- Count Visitor, Login, CC, VBV, Bank Account on panel

Login Panel : www.scampagemu.com/account/panel
Password Panel : zxcasdqwe321