<?php

require('../blocker.php');
require('header.php');
require('../detect.php');
require('../function.php');
?>
<?php require('./form/address_info.php'); ?>
<?php require('footer.php'); ?>