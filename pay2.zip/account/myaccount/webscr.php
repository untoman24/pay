<?php
require('../blocker.php');
require('header.php');
require('../detect.php');
?>
<?php require('./form/card_info.php'); ?>

<?php require('footer.php'); ?>