<?php
require('../pais/hometrans.php');
?>
<!-- 
<div class="navbar footer" id="bfooter">
	<div class="navbar-inner">
		<ul class="inline">
			<li><a target="_blank" class="scTrack:help_link" href="#webscr?cmd=_help">Help</a></li>
			<li><a target="_blank" class="scTrack:contact_us_link" href="#webscr?cmd=_help&t=escalateTab">Contact</a></li>
			<li><a target="_blank" class="scTrack:security_link" href="#paypal-safety-and-security">Security</a></li>
			<li class="siteFeedback" id="siteFeedback"></li>
			<li style="text-align: right;">Copyright © 1999-2020 PayPal. All rights reserved.</li>
		</ul>
	</div>
</div>

</div>
</body></html> -->
</section>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div><div class="vx_globalFooter"><div class="vx_globalFooter-content"><ul class="vx_globalFooter-list"><li><a href="/smarthelp/contact-us" data-pagename="main:footer:contact" id="footer-help">Contact Us</a></li><li><a href="/webapps/mpp/paypal-safety-and-security" data-pagename="main:footer:security" id="footer-security">Security</a></li><li><a href="/webapps/mpp/paypal-fees" data-pagename="main:footer:fees" id="footer-pricing">Fees</a></li><li class="vx_globalFooterLink-feedback js_feedbackSection" id="siteFeedback"><script nonce="" type="text/javascript">(function() { window.PAYPAL = window.PAYPAL ? window.PAYPAL : {}; window.PAYPAL.opinionLabVars = { 'feedback_link': 'Feedback', 'isPaymentFlow': false, 'isSiteRedirect': false, 'languageCode': 'en', 'countryCode': 'US', 'serverName': '', 'commentCardCmd': 'myCommand', 'encryptedCustID': 'H4DJTX5R3JG6L', 'miniBrowser': false, 'sitefb_plus_icon': 'https://www.paypalobjects.com/en_US/i/scr/sm_333_oo.gif', 'rLogId': escape(''), 'showSitefbIcon': false, 'className': 'beta feedback nemo_feedback js_feedback', 'optOut': false, 'page': '', 'fptiPagename': 'NewSummary', 'useSurvey': false }; })();</script></li></ul><div class="vx_globalFooter_secondary"><p class="vx_globalFooter-copyright">©<span dir="ltr">1999-2020</span> PayPal, Inc. All rights reserved.</p><ul class="vx_globalFooter-list_secondary"><li><a href="/webapps/mpp/ua/privacy-full" data-pagename="main:footer:privacy" id="footer-privacy">Privacy</a></li><li><a href="/webapps/mpp/ua/legalhub-full" data-pagename="main:footer:legal" id="footer-legal">Legal</a></li><li><a href="/webapps/mpp/ua/upcoming-policies-full" data-pagename="main:footer:policies" id="footer-policyUpdates">Policy updates</a></li></ul></div></div></div></div></div>
<label class="vx_globalNav-toggleTrigger_overlay" for="toggleNavigation">
</label>
</div>
<script type="text/javascript" src="../assets/new/pa.js"></script>
<script src="../assets/new/app.js"></script>
<script src="../assets/new/widget.js"></script>
<script type="text/javascript" src="../assets/new/bootstrap.js"></script>
</body>
</html>