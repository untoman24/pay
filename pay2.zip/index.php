<?php
header("location: account");
?>